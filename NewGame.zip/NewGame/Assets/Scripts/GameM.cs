﻿using UnityEngine;
using UnityEngine.UI;

public class GameM : MonoBehaviour {
   // public GameObject[] prefab;
    public GameObject obj;
    public Text _textScore;
    public Text _textHP;
    private float _speedSourse;
    private Cirkle _cirkle;
    public int score;
    public int HP = 3;
    public bool GamePlay = true;
    // Use this for initialization
    void Start()
    {
    //  obj = Instantiate(prefab[0], prefab[0].transform.position, Quaternion.identity);
        score = 0;
        _textScore.text = score.ToString();
        obj.transform.position = new Vector3(1, 1, 0);
    }
    public void Point()
    {
        Debug.Log("124");
        score++;
        _textScore.text = score.ToString();
    }
	
	// Update is called once per frame
	void Update () {
        if (HP == 0) GamePlay = false;
        //obj = obj ? obj : Instantiate(prefab[0], new Vector3(Random.Range(-8, 8), Random.Range(-4, 4), 0), Quaternion.identity);

        if (GamePlay) { _textScore.text = score.ToString(); _textHP.text = HP.ToString(); }
        else { _textScore.text = "you lose"; Destroy(obj); _textHP.text = HP.ToString(); }

    }
}
