﻿using UnityEngine;


public class Cirkle : MonoBehaviour {
    
  //  private Renderer render;
    public GameM GameM;
    private float speed = 1.02f;
    void Start()
    {

     //   render = GetComponent<Renderer>();
    }
    private void OnMouseDown()
    {
        GameM.score++;
        gameObject.transform.localScale = new Vector3(0.2f,0.2f,1);
        gameObject.transform.position = new Vector3(Random.Range(-8, 8), Random.Range(-4, 4), 0);
    }
    void Update () {
        if (GameM.GamePlay)
        {
            gameObject.transform.localScale = gameObject.transform.localScale * speed;
            if (gameObject.transform.localScale.x > 2.5f)
            {
                GameM.HP--;
                gameObject.transform.localScale = new Vector3(0.2f, 0.2f, 1);
                gameObject.transform.position = new Vector3(Random.Range(-8, 8), Random.Range(-4, 4), 0);
            }
        }
    }
}
